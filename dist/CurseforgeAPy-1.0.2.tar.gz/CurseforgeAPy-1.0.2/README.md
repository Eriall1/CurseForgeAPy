# CurseForgeAPy

CurseForgeAPy is a wrapper written in python for the Eternal (CurseForge) API. It covers all endpoints defined at "https://docs.curseforge.com/" and returns layered objects of the data.